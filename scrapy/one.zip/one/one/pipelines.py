# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import scrapy
from scrapy.exceptions import DropItem
from scrapy.pipelines.images import ImagesPipeline
import requests
from one import settings
import os

class OnePipeline(ImagesPipeline):

    # def handle_redirect(self, file_url):
    #     response = requests.head(file_url)
    #     if response.status_code == 302:
    #         file_url = response.headers["Location"]
    #     return file_url

    def get_media_requests(self, item, info):#重写ImagesPipeline   get_media_requests方法
        '''
        :param item:
        :param info:
        :return:
        在工作流程中可以看到，
        管道会得到文件的URL并从项目中下载。
        为了这么做，你需要重写 get_media_requests() 方法，
        并对各个图片URL返回一个Request:
        '''
        # for image_url in item['url']:
        #     yield scrapy.Request(image_url)
        # re_url=self.handle_redirect(item["url"])
        # print(re_url)
        yield scrapy.Request(item["url"], meta={'item': item}) # meta 传递 item 才能重写file_path成功

    def file_path(self, request, response=None, info=None):
        item = request.meta['item']
        path = "%s/%s/%s.%s" % (item['title'],
                                item['chapt'],
                                item['page'],'jpg')
        return path 
 
    def item_completed(self, results, item, info):
        '''
 
        :param results:
        :param item:
        :param info:
        :return:
        当一个单独项目中的所有图片请求完成时（要么完成下载，要么因为某种原因下载失败），
         item_completed() 方法将被调用。
        '''
        image_paths = [x['path'] for ok, x in results if ok]
        if not image_paths:
            raise DropItem("Item contains no images")
        return item