# -*- coding: utf-8 -*-
import scrapy
import hashlib
import re
from one.items import ImgItem
import execjs

class A733Spider(scrapy.Spider):
    name = '733'
    # allowed_domains = ['www.733.so']
    # this_url='https://www.733.so'
    # start_urls = ['https://www.733.so/mh/12071/',]

    def __init__(self,url='',*a,**kw):
        super(A733Spider,self).__init__(*a,**kw)
        self.allowed_domains = ['www.733.so']
        self.this_url='https://www.733.so'
        if self.this_url not in url:
            print('please use like: scrapy crawl 733 -a url="https://www.733.so/mh/xx/"')
            exit(0)
        # https://www.733.so/mh/12071/
        self.start_urls = [url,]

    def parse(self, response):
        clists=[self.this_url+a for a in response.xpath('//*[@id="play_0"]/ul/li/a/@href').extract()]
        for chap in clists:
            yield response.follow(chap,self.dchap)

    def dchap(self,response):
        # print(response.xpath('//h1/text()').extract())
        cjs=response.xpath('//script/text()').extract()[0]+'return photosr;'
        # print(cjs)
        cimgs=execjs.exec_(cjs)[1:]
        # print(cimgs)
        pimg=''.join(['/'+p for p in response.url.split('/')[3:]])
        # print(pimg)
        # http://img.tsjjx.com/?id=/mh/7686/77850.html&mode=pc&hash=(hex32md5(id+file))&file=img/13/13/05/5785.jpg";  # photosr[page]       
        # uimgs= ['http://img.tsjjx.com/?id={}&mode=pc&hash={}&file={}'.format(pimg,hashlib.md5((pimg+fimg).encode('utf-8')).hexdigest(),fimg) for fimg in cimgs]
        uimgs= ['http://img.hi328.com/img.php?id={}&mode=pc&hash={}&file={}'.format(pimg,hashlib.md5((pimg+fimg).encode('utf-8')).hexdigest(),fimg) for fimg in cimgs]
        # print(uimgs)
        cname=re.findall('comicname.*"(.*)"',cjs)[0]
        cchap=re.findall('viewname.*"(.*)"',cjs)[0]
        print(cname,cchap)#,uimgs)
        for i in range(len(uimgs)):
            item = ImgItem()
            item['url'] = uimgs[i].strip()
            item['page'] = i+1
            item['chapt'] = cchap.strip()
            item['title'] = cname.strip()
            yield item

